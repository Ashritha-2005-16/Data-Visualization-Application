import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.chart.*;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.stage.FileChooser;
import javafx.stage.Stage;
import java.io.*;
import java.util.*;

public class DataVizApp extends Application {

    private List<String[]> data = new ArrayList<>();

    public static void main(String[] args) {
        launch(args);
    }

    @Override
    public void start(Stage stage) {
        stage.setTitle("Data Visualization App");

        VBox root = new VBox(10);
        root.setPadding(new javafx.geometry.Insets(10));

        Label fileLabel = new Label("No file selected.");
        Button uploadBtn = new Button("Upload CSV");

        ComboBox<String> xAxisCombo = new ComboBox<>();
        ComboBox<String> yAxisCombo = new ComboBox<>();

        Button drawBtn = new Button("Draw Chart");
        CategoryAxis xAxis = new CategoryAxis();
        NumberAxis yAxis = new NumberAxis();
        BarChart<String, Number> chart = new BarChart<>(xAxis, yAxis);

        uploadBtn.setOnAction(e -> {
            FileChooser fc = new FileChooser();
            fc.getExtensionFilters().add(new FileChooser.ExtensionFilter("CSV Files", "*.csv"));
            File file = fc.showOpenDialog(stage);
            if (file != null) {
                fileLabel.setText("Loaded: " + file.getName());
                data.clear();
                try (BufferedReader br = new BufferedReader(new FileReader(file))) {
                    String line;
                    while ((line = br.readLine()) != null) {
                        data.add(line.split(","));
                    }
                    xAxisCombo.getItems().setAll(data.get(0));
                    yAxisCombo.getItems().setAll(data.get(0));
                } catch (IOException ex) {
                    ex.printStackTrace();
                }
            }
        });

        drawBtn.setOnAction(e -> {
            int xIndex = xAxisCombo.getSelectionModel().getSelectedIndex();
            int yIndex = yAxisCombo.getSelectionModel().getSelectedIndex();
            if (xIndex < 0 || yIndex < 0 || data.size() <= 1) return;

            chart.getData().clear();
            XYChart.Series<String, Number> series = new XYChart.Series<>();
            for (int i = 1; i < data.size(); i++) {
                try {
                    String x = data.get(i)[xIndex];
                    Number y = Double.parseDouble(data.get(i)[yIndex]);
                    series.getData().add(new XYChart.Data<>(x, y));
                } catch (Exception ignored) {}
            }
            chart.getData().add(series);
        });

        root.getChildren().addAll(uploadBtn, fileLabel, new Label("X-Axis:"), xAxisCombo,
                                  new Label("Y-Axis:"), yAxisCombo, drawBtn, chart);

        Scene scene = new Scene(root, 800, 600);
        stage.setScene(scene);
        stage.show();
    }
}
