# Java Data Visualization App

## Description
This is a simple JavaFX-based desktop application that allows users to upload CSV files and generate interactive bar charts. It supports selecting data columns for both axes and renders the graph using JavaFX's built-in charting tools.

## Features
- Upload CSV file
- Choose columns for X and Y axes
- View bar chart based on selected data
- Lightweight and handles simple CSV datasets

## Requirements
- Java 8+
- JavaFX SDK

## How to Run
1. Compile `DataVizApp.java`
2. Run the JavaFX application
3. Upload a CSV file (first row should be headers)
4. Select X and Y axis columns
5. Click "Draw Chart" to visualize

## Screenshot
See `screenshot.png` for a sample chart view.
